package ru.samsung.mygame;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.ScreenUtils;

public class MyGdxGame extends ApplicationAdapter {
    SpriteBatch batch;
    Texture img;
    Texture textMapTexture;
    Vector2 pos;
    OrthographicCamera camera;
    private TiledMap tiledMap;
    private OrthogonalTiledMapRenderer tmr;
    private World world;
    private Box2DDebugRenderer b2ddr;

    @Override
    public void create() {
        batch = new SpriteBatch();
        textMapTexture = new Texture("111.png");
        img = new Texture("222.png");
        pos = new Vector2(0, 0);
        camera = new OrthographicCamera(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(-50, -50, 0);
        camera.update();

        world = new World(new Vector2(0, 0), true);
        tiledMap = new TmxMapLoader().load("map.tmx");
        tmr = new OrthogonalTiledMapRenderer(tiledMap, 1, batch);
        TiledMapImporter.buildBuildingsBodies(tiledMap, world, 1, "Слой объектов 1");
        b2ddr = new Box2DDebugRenderer();
    }

    @Override
    public void render() {
        ScreenUtils.clear(0, 0, 0, 1);

        if (Gdx.input.isTouched()) {
            int x = Gdx.input.getX();
            int y = Gdx.input.getY();

            Vector3 worldPos = new Vector3(x, y, 0);
            camera.unproject(worldPos);

            float deltaX = worldPos.x - pos.x;
            float deltaY = worldPos.y - pos.y;

            Vector2 deltaPos = new Vector2(deltaX, deltaY).nor().scl(10f);
            if (deltaPos.x + pos.x > 0 && deltaPos.x + pos.x < 2850)
                pos.x += deltaPos.x;
            if (deltaPos.y + pos.y > 0 && deltaPos.y + pos.y < 2850)
                pos.y += deltaPos.y;

        }

        camera.position.set(pos, 0);
        camera.update();
        batch.setProjectionMatrix(camera.combined);

        world.step(Gdx.graphics.getDeltaTime(), 6, 2);
        tmr.setView(camera);
        tmr.render();

        batch.begin();
//        batch.draw(textMapTexture, 0, 0, 3000, 3000);
        batch.draw(img, pos.x, pos.y, 150, 150);
        batch.end();

        b2ddr.render(world, camera.combined);
    }

    @Override
    public void dispose() {
        batch.dispose();
        img.dispose();
    }
}
